<?php if($errors->any()): ?>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><div class="alert alert-dismissible fade show alert-danger"><a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a> <?php echo $error; ?></div></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<?php if(! Schema::hasTable('users') && !file_exists(storage_path('installed'))): ?>
<div class="alert alert-dismissible fade show alert-info" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    It's looks like, you are not install the application yet, please <a href="<?php echo e(url('/install')); ?>">install</a> it first.
</div>
<?php endif; ?>

<?php if(session('info')): ?>
<div class="alert alert-dismissible fade show alert-info" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo session('info'); ?>

</div>
<?php endif; ?>
<?php if(session('status')): ?>
<div class="alert alert-dismissible fade show alert-success" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    &nbsp;<?php echo session('status'); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-dismissible fade show alert-success" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo session('success'); ?>

</div>
<?php endif; ?>
<?php if(session('danger')): ?>
<div class="alert alert-dismissible fade show alert-danger" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo session('danger'); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-dismissible fade show alert-danger" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo session('error'); ?>

</div>
<?php endif; ?>
<?php if(session('warning')): ?>
<div class="alert alert-dismissible fade show alert-warning" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo session('warning'); ?>

</div>
<?php endif; ?>
<?php if(session('message')): ?>
<div class="alert alert-dismissible fade show alert-info" role="alert">
    <a href="javascript:void(0)" class="close" data-dismiss="alert" aria-label="close">&nbsp;</a>
    <?php echo e(session('message')); ?>

</div>
<?php endif; ?><?php /**PATH /Users/magic/Sites/tokenlite/tokenlite_app/resources/views/layouts/messages.blade.php ENDPATH**/ ?>