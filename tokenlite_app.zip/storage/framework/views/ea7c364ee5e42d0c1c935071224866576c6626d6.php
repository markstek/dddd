
<?php $__env->startSection('title', 'Edit Payment Method'); ?>

<?php $__env->startSection('content'); ?>
<?php echo e($method); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/magic/Sites/tokenlite/tokenlite_app/resources/views/admin/payments-method-edit.blade.php ENDPATH**/ ?>