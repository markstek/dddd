
<?php $__env->startSection('title', 'ICO/STO Stage'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container">
        <div class="card content-area">
            <div class="card-innr">
                <div class="card-head d-flex justify-content-between align-items-center">
                    <h4 class="card-title mb-0">ICO/STO Stage Update</h4>
                    <div class="d-flex guttar-15px">
                        <div class="fake-class">
                            <span class="badge badge-lg badge-dim badge-lighter d-none d-md-inline-block">Sold: <?php echo e(number_format($ico->soldout, 2).' '. token_symbol()); ?></span>
                        </div>
                        <div class="fake-class">
                            <form action="<?php echo e(route('admin.ajax.stages.active')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <a href="javascript:void(0);" id="update_stage" data-type = "active_stage" data-id="<?php echo e($ico->id); ?>" class="btn btn-icon btn-sm btn-<?php echo e((get_setting('actived_stage') == $ico->id)?'danger disabled':'danger-alt'); ?>"><em class="fas fa-star"></em></a>
                                <input class="input-bordered" type="hidden" name="actived_stage" value="<?php echo e($ico->id); ?>">
                            </form>
                        </div>
                        <div class="fake-class">
                            <a href="<?php echo e(route('admin.stages')); ?>" class="btn btn-sm btn-auto btn-primary d-sm-inline-block d-none"><em class="fas fa-arrow-left"></em><span>Back</span></a>
                            <a href="<?php echo e(route('admin.stages')); ?>" class="btn btn-icon btn-sm btn-primary d-sm-none"><em class="fas fa-arrow-left"></em></a>
                        </div>
                    </div>
                </div>
                <div class="gaps-1x"></div>
                <ul class="nav nav-tabs nav-tabs-line" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#ico_stage">Stage Details</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#ico_stage_price">Pricing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#ico_stage_bonus">Bonuses</a>
                    </li>
                </ul>
                <div class="tab-content" id="ico-details">
                    <div class="tab-pane fade show active" id="ico_stage">
                        <form action="<?php echo e(route('admin.ajax.stages.update')); ?>" class="_reload validate-modern" method="POST" id="ico_stage" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="ico_id" value="<?php echo e($ico->id); ?>">
                            <div id="stageDetails" class="wide-max-md">
                                
                                <div class="input-item input-with-label">
                                    <label class="input-item-label">Stage Title/Name
                                        <?php if((date('Y-m-d H:i:s') >= $ico->start_date) && (date('Y-m-d H:i:s') <= $ico->end_date) && (get_setting('actived_stage') == $ico->id) && ($ico->status != 'paused')): ?>
                                        <span class="ucap badge badge-success ml-2">Running</span>
                                        <?php elseif((date('Y-m-d H:i:s') >= $ico->start_date && date('Y-m-d H:i:s') <= $ico->end_date) && ($ico->status == 'paused')): ?>
                                        <span class="ucap badge badge-purple ml-2">Paused</span>
                                        <?php elseif((date('Y-m-d H:i:s') >= $ico->start_date && date('Y-m-d H:i:s') <= $ico->end_date) && ($ico->status != 'paused')): ?>
                                        <span class="ucap badge badge-secondary ml-2">Inactive</span>
                                        <?php elseif($ico->start_date > date('Y-m-d H:i:s') && date('Y-m-d H:i:s') < $ico->end_date): ?>
                                        <span class="ucap badge badge-warning ml-2">Upcoming</span>
                                        <?php elseif(($ico->start_date > date('Y-m-d H:i:s')) && (date('Y-m-d H:i:s') < $ico->end_date)): ?>
                                        <span class="ucap badge badge-info ml-2">Completed</span>
                                        <?php else: ?>
                                        <span class="ucap badge badge-danger ml-2">Expired</span>
                                        <?php endif; ?>
                                    </label>
                                   <div class="input-wrap">
                                    <input class="input-bordered" type="text" name="name" value="<?php echo e($ico->name); ?>" required>
                                </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">Total Token Issues</label>
                                           <div class="input-wrap">
                                            <input class="input-bordered" type="number" min="1" name="total_tokens" value="<?php echo e($ico->total_tokens); ?>" required  >
                                            </div>
                                            <span class="input-note">Define how many tokens available for sale on stage.</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">Base Token Price</label>
                                           <div class="input-wrap">
                                            <input class="input-bordered" type="number" min="0" name="base_price" value="<?php echo e($ico->base_price); ?>" required>
                                            </div>
                                            <span class="input-note">Define your token rate. Usually $0.25 <?php echo e(base_currency(true)); ?> per token.</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">Min and Max Per Transaction</label>
                                            <div class="row align-items-center">
                                                <div class="col">
                                                    <div class="relative">
                                                       <div class="input-wrap">
                                                        <input class="input-bordered" type="number" placeholder="Min" name="min_purchase" min="1" value="<?php echo e($ico->min_purchase); ?>">
                                                   </div>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="relative">
                                                       <div class="input-wrap">
                                                        <input class="input-bordered" type="number" placeholder="Max" name="max_purchase" min="1" max="<?php echo e($ico->total_tokens); ?>" value="<?php echo e($ico->max_purchase); ?>">
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <span class="input-note">Purchase min or max amount of token per tranx.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="row">
                                            <div class="col-sm">
                                                <div class="input-item input-with-label">
                                                    <label class="input-item-label">Soft Cap</label>
                                                   <div class="input-wrap">
                                                    <input class="input-bordered" type="number" name="soft_cap" value="<?php echo e(($ico->soft_cap > 1 ? $ico->soft_cap : '')); ?>" max="<?php echo e($ico->total_tokens); ?>">
                                               </div>
                                                </div>
                                            </div>
                                            <div class="col-sm">
                                                <div class="input-item input-with-label">
                                                    <label class="input-item-label">Hard Cap</label>
                                                   <div class="input-wrap">
                                                    <input class="input-bordered" type="number" name="hard_cap" value="<?php echo e(($ico->hard_cap > 1 ? $ico->hard_cap : '')); ?>" max="<?php echo e($ico->total_tokens); ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div class="col-12 d-none">
                                                <div class="input-item input-with-label">
                                                    <label class="input-item-label">Display Token as</label>
                                                    <select class="select select-block select-bordered" name="display_mode">
                                                        <option <?php echo e($ico->display_mode == 'normal' ? 'selected' : ''); ?> value="normal">Base -> Token</option>
                                                        <option <?php echo e($ico->display_mode == 'reverse' ? 'selected' : ''); ?> value="reverse">Token -> Base</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 mb-4 mt-1">
                                        <div class="sap"></div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">Start Date</label>
                                            <div class="row guttar-15px align-items-center">
                                                <div class="col-7 col-sm-7">
                                                    <div class="input-wrap">
                                                        <input class="input-bordered date-picker" type="text" name="start_date" value="<?php echo e(stage_date($ico->start_date)); ?>"  required>
                                                        <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                    </div>
                                                </div>
                                                <div class="col-5 col-sm-5">
                                                    <div class="input-wrap">
                                                        <input class="input-bordered time-picker" type="text" name="start_time" value="<?php echo e(stage_time($ico->start_date)); ?>" >
                                                        <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <span class="input-note">Start date/time for sale. Can't purchase before time.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">End Date</label>
                                            <div class="row guttar-15px align-items-center">
                                                <div class="col-7 col-sm-7">
                                                    <div class="input-wrap">
                                                        <input class="input-bordered custom-date-picker" type="text" name="end_date" value="<?php echo e(stage_date($ico->end_date)); ?>"  required>
                                                        <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                    </div>
                                                </div>
                                                <div class="col-5 col-sm-5">
                                                   <div class="input-wrap">
                                                        <input class="input-bordered time-picker" type="text" name="end_time" value="<?php echo e(stage_time($ico->end_date, 'end')); ?>" >
                                                        <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <span class="input-note">Finish date/time for sale. Can't purchase after time.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="input-item input-with-label">
                                            <div class="row guttar-15px align-items-center">
                                                <div class="col-12">
                                                    <div class="input-wrap">
                                                        <input type="checkbox" class="input-switch" id="sale_pause" <?php echo e(($ico->status != 'paused')?'checked ':''); ?>name="sale_pause">
                                                        <label for="sale_pause">Sales Running</label>
                                                    </div>
                                                    <span class="input-note">Disable this, if you want to stop sale temporary. Note: Contributor still able to calculate token.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gaps-1-5x"></div>
                                <div class="d-flex">
                                    <button class="btn btn-primary save-disabled" type="submit" disabled="">Update Stage</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="ico_stage_price">
                        <form class="form-wrap w-xl-16x validate-modern" action="<?php echo e(route('admin.ajax.stages.meta.update')); ?>" method="POST" id="ico_stage_price" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="req_type" value="price_option">
                            <input type="hidden" name="ico_id" value="<?php echo e($ico->id); ?>">
                            <div id="stagePrice">
                                <?php
                                $pd = $prices;
                                ?>
                                <div class="stage-tire-group">
                                    <div class="stage-tire-item">
                                        <?php for($i=1; $i <= 3; $i++): ?>
                                        <?php $tire = 'tire_'.$i; ?>
                                        <div class="stage-tire-title">
                                            <div class="input-item pb-0">
                                                <input class="input-switch input-switch-left switch-toggle" data-switch="switch-to-priceTier0<?php echo e($i); ?>" <?php echo e($pd->$tire->status == 1 ? 'checked' : ''); ?>  type="checkbox" id="priceTier0<?php echo e($i); ?>" name="ptire_<?php echo e($i); ?>" value="1">
                                                <label for="priceTier0<?php echo e($i); ?>"></label>
                                            </div>
                                            <span class="h5">Price Tier - 0<?php echo e($i); ?></span>
                                        </div>
                                        <div class="switch-content switch-to-priceTier0<?php echo e($i); ?> wide-max-md">
                                            <div class="row">
                                                <div class="col-md">
                                                    <div class="input-item input-with-label">
                                                        <label class="input-item-label">Token Price</label>
                                                        <div class="input-wrap">
                                                            <input class="input-bordered" type="text" min="0" name="ptire_<?php echo e($i); ?>_token_price" value="<?php echo e($pd->$tire->price); ?>">
                                                            <span class="input-note">Base Price: <span><?php echo e($ico->base_price.' '.base_currency(true)); ?></span></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md">
                                                    <div class="input-item input-with-label">
                                                        <label class="input-item-label">Min Purchase</label>
                                                        <div class="input-wrap">
                                                            <input class="input-bordered" type="number" name="ptire_<?php echo e($i); ?>_min_purchase" min="0" value="<?php echo e($pd->$tire->min_purchase); ?>">
                                                            <span class="input-note">Base Min: <span><?php echo e($ico->min_purchase); ?> <?php echo e(token('symbol')); ?></span>. '0' to set as base.</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md">
                                                    <div class="input-item input-with-label">
                                                        <label class="input-item-label">Start Date</label>
                                                        <div class="row guttar-15px">
                                                            <div class="col-7 col-sm-7">
                                                                <div class="input-wrap">
                                                                    <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                                    <input class="input-bordered custom-date-picker" id="pdate_start" type="text" name="ptire_<?php echo e($i); ?>_start_date" value="<?php echo e(stage_date($pd->$tire->start_date)); ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-5 col-sm-5">
                                                                <div class="input-wrap">
                                                                    <input class="input-bordered time-picker" type="text" name="ptire_<?php echo e($i); ?>_start_time" value="<?php echo e(stage_time($pd->$tire->start_date)); ?>">
                                                                    <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-12">
                                                                <span class="input-note">Start date/time for sale.</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md">
                                                    <div class="input-item input-with-label">
                                                        <label class="input-item-label">End Date</label>
                                                        <div class="row guttar-15px">
                                                            <div class="col-7 col-sm-7">
                                                                <div class="input-wrap">
                                                                    <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                                    <input class="input-bordered custom-date-picker" type="text" name="ptire_<?php echo e($i); ?>_end_date" value="<?php echo e(stage_date($pd->$tire->end_date)); ?>"  data-msg-greaterThan="End date is must be greater then start date">
                                                                </div>
                                                            </div>
                                                            <div class="col-5 col-sm-5">
                                                                <div class="input-wrap">
                                                                    <input class="input-bordered time-picker" type="text" name="ptire_<?php echo e($i); ?>_end_time" value="<?php echo e(stage_time($bonuses->base->end_date, 'end')); ?>">
                                                                    <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-12">
                                                                <span class="input-note">Finish date/time for sale.</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div class="gaps-1x"></div>
                                <div class="d-flex pdb-2-5x">
                                    <button class="btn btn-primary save-disabled" type="submit" disabled>Update Price</button>
                                </div>
                                <div class="sap"></div>
                                <div class="gaps-2x"></div>
                                <div class="notes">
                                    <ul>
                                       <li>^ Price will set lowest amount, if you multiple condition of price applied on same date.</li>
                                       <li>^ Stage date and time will set if not defined date and time in each pricing option.</li>
                                   </ul>
                               </div>
                           </div>
                       </form>
                   </div>
                   <div class="tab-pane fade" id="ico_stage_bonus">
                    <form action="<?php echo e(route('admin.ajax.stages.meta.update')); ?>" class="validate-modern" method="POST" id="ico_stage_bonus" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="req_type" value="bonus_option">
                        <input type="hidden" name="ico_id" value="<?php echo e($ico->id); ?>">
                        <div  id="stageBonus">
                            
                            <div class="stage-tire-group">
                                <div class="stage-tire-item wide-max-md">
                                    <div class="stage-tire-title">
                                        <span class="h5">Base Bonus</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="input-item input-with-label">
                                                <label class="input-item-label">Bonus Amount</label>
                                                <div class="d-flex guttar-20px align-items-center">
                                                    <div class="w-120px">
                                                        <div class="input-wrap">
                                                            <input min="0" max="100" class="input-bordered" type="number" name="bb_amount" value="<?php echo e($bonuses->base->amount); ?>">
                                                        
                                                            <span class="input-hint input-hint-lg"><span>%</span></span>
                                                        </div>
                                                    </div>
                                                    <div class="fake-class">
                                                        <span class="input-note pt-0">Usually 1-100%. <br>Extra tokens will add to contributor account.</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md">
                                            <div class="input-item input-with-label">
                                                <label class="input-item-label">Start Date</label>
                                                <div class="row guttar-15px">
                                                    <div class="col-7 col-sm-7">
                                                        <div class="input-wrap">
                                                           <input class="input-bordered custom-date-picker" type="text" name="bb_start_date" id="bbdate_end" value="<?php echo e(stage_date($bonuses->base->start_date)); ?>">
                                                           <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                       </div>
                                                   </div>
                                                   <div class="col-5 col-sm-5">
                                                    <div class="input-wrap">
                                                        <input class="input-bordered time-picker" type="text" name="bb_start_time" value="<?php echo e(stage_time($bonuses->base->start_date)); ?>">
                                                        <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <span class="input-note">Start date/time for Bonus.</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md">
                                        <div class="input-item input-with-label">
                                            <label class="input-item-label">End Date</label>
                                            <div class="row guttar-15px">
                                                <div class="col-7 col-sm-7">
                                                    <div class="input-wrap">
                                                       <input class="input-bordered custom-date-picker" type="text" name="bb_end_date" value="<?php echo e(stage_date($bonuses->base->end_date)); ?>"  data-msg-greaterThan="End date is must be greater then start date">
                                                       <span class="input-icon input-icon-right date-picker-icon"><em class="ti ti-calendar"></em></span>
                                                   </div>
                                               </div>
                                               <div class="col-5 col-sm-5">
                                                <div class="input-wrap">
                                                    <input class="input-bordered time-picker" type="text" name="bb_end_time" value="<?php echo e(stage_time($bonuses->base->end_date, 'end')); ?>">
                                                    <span class="input-icon input-icon-right time-picker-icon"><em class="ti ti-alarm-clock"></em></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <span class="input-note">Finish date/time for Bonus.</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="stage-tire-item">
                            <div class="stage-tire-title">
                                <div class="input-item pb-1">
                                   <input class="input-switch switch-toggle" data-switch="switch-to-bonusAmount" type="checkbox" id="bonusAmount" <?php echo e($bonuses->bonus_amount->status == 1 ? 'checked' : ''); ?> name="bonus_amount">
                                   <label for="bonusAmount"></label>
                               </div>
                               <div>
                                <span class="h5">Based on Tokens</span>
                                <p>You can specify bonus based on token sales amount.</p>
                            </div>
                        </div>
                        <div class="switch-content switch-to-bonusAmount wide-max-md">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="row guttar-15px ">
                                        <div class="col-7 col-sm-6">
                                            <label class="input-item-label">Minimum Token</label>
                                        </div>
                                        <div class="col-5 col-sm-3">
                                            <label class="input-item-label">Bonus %</label>
                                        </div>
                                    </div>
                                    <?php $ba = $bonuses->bonus_amount; ?>
                                    <?php for($i=1; $i <=3; $i++): ?>
                                    <?php $ba_tire = 'tire_'.$i; ?>
                                    <div class="pdb-2x">
                                        <div class="row guttar-15px guttar-vr-5px align-items-center">
                                            <div class="col-7 col-sm-6">
                                                <div class="input-wrap">
                                                    <input class="input-bordered" type="number" min="1" max="<?php echo e($ico->total_tokens); ?>" name="ba_token_<?php echo e($i); ?>" value="<?php echo e($ba->$ba_tire->token); ?>">
                                                    <span class="input-hint"><span><?php echo e(token('symbol')); ?></span></span>
                                                </div>
                                            </div>
                                            <div class="col-5 col-sm-3">
                                                <div class="input-wrap">
                                                   <input class="input-bordered" type="number" min="1" max="100" name="ba_amount_<?php echo e($i); ?>" value="<?php echo e($ba->$ba_tire->amount); ?>">
                                                   <span class="input-hint input-hint-lg"><span>%</span></span>
                                               </div>
                                           </div>
                                           <div class="col">
                                            <div class="input-sub-label">Tier <?php echo e($i); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="gaps-1x"></div>
            <div class="d-flex pdb-2-5x">
                <button class="btn btn-primary save-disabled" disabled="" type="submit" disabled> Update Bonus</button>
            </div>
            <div class="sap"></div>
            <div class="gaps-2x"></div>
            <div class="notes">
               <ul>
                   <li>^ Bonus will set highest amount, if you multiple condition of bonus applied on same date.</li>
                   <li>^ Stage date and time will set if not defined date and time in each bonus option.</li>
               </ul>
           </div>
       </div>
   </form>
</div>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/magic/Sites/tokenlite/tokenlite_app/resources/views/admin/ico-stage-edit.blade.php ENDPATH**/ ?>