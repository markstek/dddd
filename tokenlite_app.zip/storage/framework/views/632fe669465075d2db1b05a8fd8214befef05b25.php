
<?php $__env->startSection('title', 'Activity'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container">
        <div class="row">
            <div class="main-content col-lg-12">
                <?php echo $__env->make('vendor.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card content-area content-area-mh">
                    <div class="card-innr">
                        <div class="card-head has-aside">
                            <h4 class="card-title">Recent Activity</h4>
                            <div class="card-opt">
                                <ul class="btn-grp btn-grp-block guttar-20px">
                                    <li>
                                        <input type="hidden" id="activity_action" value="<?php echo e(route('admin.ajax.profile.activity.delete')); ?>">
                                        <a href="javascript:void(0)" data-id="all" class="btn btn-sm btn-auto btn-primary d-sm-block d-none activity-delete"><i class="fas fa-cog mr-2"></i>Clear Log</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <table class="data-table dt-init activity-list" data-items="10">
                            <thead>
                                <tr class="data-item data-head">
                                    <th class="data-col">Date</th>
                                    <th class="data-col d-none d-sm-table-cell">Device</th>
                                    <th class="data-col">Browser</th>
                                    <th class="data-col">IP</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody id="activity-log">
                                <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                $browser = explode('/', $activity->browser);
                                $device = explode('/', $activity->device);
                                $ip = ($activity->ip == '::1' || $activity->ip == '127.0.0.1') ? 'localhost' : $activity->ip ;
                                ?>
                                <tr class="data-item activity-<?php echo e($activity->id); ?>">
                                    <td class="data-col"><?php echo e(_date($activity->created_at)); ?></td>
                                    <td class="data-col d-none d-sm-table-cell"><?php echo e(end($device)); ?></td>
                                    <td class="data-col"><?php echo e($browser[0]); ?></td>
                                    <td class="data-col"><?php echo e($ip); ?></td>
                                    <td class="data-col"><a href="javascript:void(0)" class="activity-delete text-dark fs-12" data-id="<?php echo e($activity->id); ?>" title="delete activity"><em class="fas fa-trash"></em></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4">No Activity Found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/magic/Sites/tokenlite/tokenlite_app/resources/views/admin/activity.blade.php ENDPATH**/ ?>