<?php

namespace App\Exceptions;

Use Throwable;

class APIException extends Exception
{
    //
}
